import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [enteredGoalText, setEnteredGoalText] = useState('');
  const [courseGoals, setCourseGoals] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);

  const goalInputHandler = (enteredText) => {
    setEnteredGoalText(enteredText);
  };

  const addGoalHandler = () => {
    if (editingIndex !== null) {
      const updatedGoals = [...courseGoals];
      updatedGoals[editingIndex] = {
        text: enteredGoalText,
        id: updatedGoals[editingIndex].id,
        hidden: updatedGoals[editingIndex].hidden, 
      };
      setCourseGoals(updatedGoals);
      setEditingIndex(null);
    } else {
      setCourseGoals((currentCourseGoals) => [
        ...currentCourseGoals,
        {
          text: enteredGoalText,
          id: Math.random().toString(),
          hidden: false, 
        },
      ]);
    }
    setEnteredGoalText('');
  };

  const deleteGoal = (index) => {
    const updatedGoals = [...courseGoals];
    updatedGoals.splice(index, 1);
    setCourseGoals(updatedGoals);
  };

  const toggleHideGoal = (index) => {
    const updatedGoals = [...courseGoals]; 
    updatedGoals[index] = {
      ...updatedGoals[index], 
      hidden: !updatedGoals[index].hidden, 
    };
    setCourseGoals(updatedGoals); 
  };

  const startEditing = (index) => {
    setEnteredGoalText(courseGoals[index].text);
    setEditingIndex(index);
  };

  const getRainbowColor = (index) => {
    const colors = ['#9acd32', '#ffff00', '#808000'];
    return { backgroundColor: colors[index % colors.length] };
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter your goal"
          onChangeText={goalInputHandler}
          value={enteredGoalText}
        />
        <Button title={editingIndex !== null ? 'Edit Goal' : 'Add Goal'} onPress={addGoalHandler} />
      </View>

      <FlatList
        data={courseGoals} // Show all goals
        renderItem={({ item, index }) => (
          <View style={[styles.goalContainer, getRainbowColor(index)]}>
            {!item.hidden && <Text>{item.text}</Text>} {}
            <View style={styles.buttonContainer}>
              <TouchableOpacity onPress={() => toggleHideGoal(index)}>
                <Text>{item.hidden ? 'Unhide' : 'Hide'}</Text> {}
              </TouchableOpacity>
              {!item.hidden && (
                <>
                  <TouchableOpacity onPress={() => startEditing(index)}>
                    <Text>Edit</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => deleteGoal(index)}>
                    <Text>Delete</Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f8f9fa',
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    width: '75%',
    marginRight: 10,
  },
  goalContainer: {
    padding: 15,
    marginVertical: 5,
    borderRadius: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 10,
  },
});
