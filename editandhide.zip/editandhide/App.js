import React, { useState } from 'react';
import { ScrollView, Text, View, Switch, Alert, TouchableOpacity, StyleSheet } from 'react-native';

const ClothesSelection = () => {
  const [choicesState, setChoicesState] = useState({});

  const toggleClothesChoice = (item1, item2) => {
    setChoicesState((prev) => ({
      ...prev,
      [item1]: !prev[item1],
      [item2]: prev[item1],
    }));
  };

  const clothesList = [
    ['shirt1', 'shirt2'],
    ['pants1', 'pants2'],
    ['hat1', 'hat2'],
    ['shoes1', 'shoes2'],
    ['jacket1', 'jacket2'],
  ];

  const submitSelection = () => {
    const selectedItems = Object.keys(choicesState).filter((item) => choicesState[item]);
    const outputMessage = selectedItems.length > 0
      ? selectedItems.map((item, idx) => `${idx + 1}. ${item}`).join('\n')
      : 'No items selected';
    Alert.alert('Your Clothes Choices:', outputMessage);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Pick Your Clothes Order:</Text>
      {clothesList.map(([item1, item2]) => (
        <View style={styles.toggle} key={item1}>
          <Text style={styles.left}>{item1}</Text>
          <Switch
            value={choicesState[item1] || false}
            onValueChange={() => toggleClothesChoice(item1, item2)}
          />
          <Text style={styles.right}>{item2}</Text>
        </View>
      ))}
      <TouchableOpacity style={styles.button} onPress={submitSelection}>
        <Text style={styles.buttonText}>Submit Your Choices</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f4f4f4',
    padding: 20,
  },
  title: {
    color: '#1e3d58',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  left: {
    color: '#2f4f4f',
    marginRight: 10,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  right: {
    color: '#2f4f4f',
    marginLeft: 10,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  toggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#e0f7fa',
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
    width: '100%',
  },
  button: {
    backgroundColor: '#00796b',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginTop: 30,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ClothesSelection;
